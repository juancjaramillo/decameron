<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($documentationTitle); ?></title>
    <link rel="stylesheet" href="<?php echo e(l5_swagger_asset($documentation, 'swagger-ui.css')); ?>">
    <link rel="icon" href="<?php echo e(l5_swagger_asset($documentation, 'favicon-32x32.png')); ?>" sizes="32x32"/>
    <link rel="icon" href="<?php echo e(l5_swagger_asset($documentation, 'favicon-16x16.png')); ?>" sizes="16x16"/>
    <style>
        html { box-sizing: border-box; overflow-y: scroll; }
        *, *:before, *:after { box-sizing: inherit; }
        body { margin:0; background: #fafafa; }
    </style>
    <?php if(config('l5-swagger.defaults.ui.display.dark_mode')): ?>
    <style>/* estilos dark mode omitidos */</style>
    <?php endif; ?>
</head>
<body <?php if(config('l5-swagger.defaults.ui.display.dark_mode')): ?> id="dark-mode" <?php endif; ?>>
<div id="swagger-ui"></div>

<script src="<?php echo e(l5_swagger_asset($documentation, 'swagger-ui-bundle.js')); ?>"></script>
<script src="<?php echo e(l5_swagger_asset($documentation, 'swagger-ui-standalone-preset.js')); ?>"></script>
<script>
window.onload = function() {
    const urls = [];
    <?php $__currentLoopData = $urlsToDocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    urls.push({ name: "<?php echo e($title); ?>", url: "<?php echo e($url); ?>" });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    const ui = SwaggerUIBundle({
        dom_id: '#swagger-ui',
        urls: urls,
        "urls.primaryName": "<?php echo e($documentationTitle); ?>",
        operationsSorter: <?php echo isset($operationsSorter) ? '"' . $operationsSorter . '"' : 'null'; ?>,
        configUrl:        <?php echo isset($configUrl) ? '"' . $configUrl . '"' : 'null'; ?>,
        validatorUrl:     <?php echo isset($validatorUrl) ? '"' . $validatorUrl . '"' : 'null'; ?>,
        oauth2RedirectUrl: "<?php echo e(route('l5-swagger.'.$documentation.'.oauth2_callback', [], $useAbsolutePath)); ?>",
        requestInterceptor: function(request) {
            return request;
        },
        presets: [
            SwaggerUIBundle.presets.apis,
            SwaggerUIStandalonePreset
        ],
        plugins: [
            SwaggerUIBundle.plugins.DownloadUrl
        ],
        layout: "StandaloneLayout",
        docExpansion: "<?php echo config('l5-swagger.defaults.ui.display.doc_expansion', 'none'); ?>",
        deepLinking: true,
        filter: <?php echo config('l5-swagger.defaults.ui.display.filter') ? 'true' : 'false'; ?>,
        persistAuthorization: "<?php echo config('l5-swagger.defaults.ui.authorization.persist_authorization') ? 'true' : 'false'; ?>",
    });

    window.ui = ui;

    // ——— INYECCIÓN AUTOMÁTICA DEL TOKEN ———
    const creds = { email: 'prueba@prueba.com', password: 'prueba123' };
    fetch('/api/v1/auth/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(creds),
    })
    .then(res => res.json())
    .then(json => {
        if (!json.token) return;
        ui.authActions.authorize({
            sanctum: {
                name: 'Authorization',
                schema: { type: 'apiKey', in: 'header', name: 'Authorization' },
                value: 'Bearer ' + json.token
            }
        });
    })
    .catch(console.error);
};
</script>
</body>
</html>
<?php /**PATH C:\xampp82\htdocs\decameron\backend\resources\views/vendor/l5-swagger/index.blade.php ENDPATH**/ ?>