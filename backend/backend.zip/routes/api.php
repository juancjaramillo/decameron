<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthTokenController;
use App\Http\Controllers\Api\HotelController;
use App\Http\Controllers\Api\HotelRoomConfigController;

Route::prefix('v1')->group(function () {
    // login vía Bearer‐token
    Route::post('login',      [AuthTokenController::class, 'login']);
    Route::post('auth/token', [AuthTokenController::class, 'login']);

    // rutas protegidas por Bearer‐token
    Route::middleware('auth:sanctum')->group(function () {
        Route::apiResource('hoteles', HotelController::class);
        Route::apiResource('hoteles.configuraciones', HotelRoomConfigController::class)
             ->shallow()
             ->only(['index','store','destroy']);
    });
});
